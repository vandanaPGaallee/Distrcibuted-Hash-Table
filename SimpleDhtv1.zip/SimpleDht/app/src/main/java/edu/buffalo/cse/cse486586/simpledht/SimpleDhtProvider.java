package edu.buffalo.cse.cse486586.simpledht;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

import static android.content.ContentValues.TAG;
import static android.content.Context.MODE_PRIVATE;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
public class SimpleDhtProvider extends ContentProvider {
    static final String[] ports = {"11108", "11112", "11116", "11120", "11124"};
    static final List<String> port_list = new ArrayList(Arrays.asList(ports));
    static final int SERVER_PORT = 10000;
    TreeMap<String, String> tmap = new TreeMap<String, String>();
    private String myPort = null;
    private ContentResolver mContentResolver = null;
    private Uri mUri = null;
    private static final String KEY_FIELD = "key";
    private static final String VALUE_FIELD = "value";
    private static String predecessor = null;
    private static String successor = null;
    private static String Hash_successor = null;
    private static String Hash_predessor = null;
    private static String Hash_myport = null;
    private static Boolean Node_Join_Complete = false;
    private static Boolean Node_Join_Complete_2 = false;
    private static String Status_Node_Join_Complete = "Node_Join_Complete";
    private static String Status_Node_Join_Request = "Node_Join";
    private static String Status_Msg_Forward = "Msg_Forward";
    private static String Status_Query_All = "Query_msg";
    private static String Status_Query_One = "Query_One";
    private static String Status_Query_Found = "Query_Found";
    private static String Status_Node_Number = "Node_Number";
    private static String Status_Delete_All = "Delete_All";
    private static String Status_Delete_One = "Delete_One";
    private static int Node_Count = 0;
    Lock lock = new ReentrantLock();
    private final CountDownLatch countDownLatch = new CountDownLatch(1);
    HashMap<String, String> mapping = new HashMap<String, String>() {{
        put("11108","5554");
        put("11112","5556");
        put("11116","5558");
        put("11120","5560");
        put("11124","5562");
    }};
    HashMap<String, String> localcopy = new HashMap<String, String>();
    HashMap<String, String> globalcopy = new HashMap<String, String>();

    private Uri buildUri(String scheme, String authority) {
        Uri.Builder uriBuilder = new Uri.Builder();
        uriBuilder.authority(authority);
        uriBuilder.scheme(scheme);
        return uriBuilder.build();
    }

    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

        private boolean testInsert(String key, String msg) {
            ContentValues cv = new ContentValues();
            cv.put(KEY_FIELD, key);
            cv.put(VALUE_FIELD, msg);
            try {
                insert(mUri, cv);
            } catch (Exception e) {
                Log.e(TAG, e.toString());
                return false;
            }

            return true;
        }

        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];
            try {
                while (true) {
                    Socket socketline = serverSocket.accept();
                    BufferedReader br = new BufferedReader(new InputStreamReader(socketline.getInputStream()));
                    String input = br.readLine();
                    Log.d("PA3", "Message from client" + input + "\t\n");
                    OutputStream os = socketline.getOutputStream();
                    if(input.split("-")[0].equals(Status_Query_All)) {
                        ObjectOutputStream out_obj = new ObjectOutputStream(os);
//                        Log.d("PA3", "Query All");
                        out_obj.writeObject(localcopy);
                        continue;
                    }
                    processInput(input);
                    publishProgress(input);
                    PrintWriter out = new PrintWriter(os, true);
                    out.println("Received");
                    out.flush();
                }
            } catch (NullPointerException e) {
                Log.e(TAG, "Server Null pointer exception");
            } catch (UnknownHostException e) {
                Log.e(TAG, "ServerTask UnknownHostException");
            } catch (IOException e) {
                Log.e(TAG, "server socket connection exception");
                e.printStackTrace();
            }

            return null;
        }

        protected  void sampleTest(String key) {
            List<String> sortedList = new ArrayList<String>();
            try {
                sortedList.add(genHash(key));
                sortedList.add(genHash(mapping.get(myPort)));
                sortedList.add(genHash(mapping.get(predecessor)));
                sortedList.add(genHash(mapping.get(successor)));

            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
            String s_list = TextUtils.join(", ", sortedList);
            Log.d("CHECK", "List1  - " + s_list + "\t\n");
            Collections.sort(sortedList);
            s_list = TextUtils.join(", ", sortedList);
            Log.d("CHECK", "List2 - " + s_list + "\t\n");

        }

        protected  void processInput(String input) {
            String strReceived = input.trim();
            String[] split = strReceived.split("-");
            String req_type = split[0];
            if (req_type.equals(Status_Node_Join_Request)) {
                Log.d("PA3", "Node Join req from client - " + input + "\t\n");
                try {
                    port_list.remove(split[1]);
                    tmap.put(genHash(mapping.get(split[1])), split[1]);
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
//                Log.d("PA3", "tmap - " + tmap.toString());
            } else if (req_type.equals(Status_Node_Join_Complete)) {
                predecessor = split[2];
                successor = split[3];
                try {
                    Log.d("PA3", "My predecessor - " + predecessor + " My successor - " + successor + "my port - " + myPort);
                    Hash_predessor = genHash(mapping.get(predecessor));
                    Hash_successor = genHash(mapping.get(successor));
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }


            } else if (req_type.equals(Status_Msg_Forward)) {
//                Log.d("PA3", "Received forward message - " + strReceived );
                try {
//                    Log.d("PA3", "split array - " + " - " + split[0] + " - " + split[1] +  " - " + split[2] + " - " + split[3]);
//                    Log.d("TESTING", "myport - " + myPort + "-" + mapping.get(myPort) + "pred - " + predecessor + "-" + mapping.get(predecessor));
                    if (genHash(split[2]).compareTo(Hash_myport) <= 0 && genHash(split[2]).compareTo(Hash_predessor) > 0) {
//                        Log.d("TESTING", "Failed 1st check");
                        testInsert(split[2], split[3]);
                    } else if (Hash_predessor.compareTo(Hash_myport) >= 0 && (genHash(split[2]).compareTo(Hash_predessor) > 0 || genHash(split[2]).compareTo(Hash_myport) < 0) ){
//                        Log.d("TESTING", "Failed 2nd check");
                        testInsert(split[2], split[3]);
                    } else {
//                        sampleTest(split[2]);
                        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, strReceived, myPort);
                    }
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
            } else if (req_type.equals(Status_Query_One)) {
                if(localcopy.containsKey(split[2])) {
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, Status_Query_Found + "-" + split[1] +"-" + split[2]+ "-" + localcopy.get(split[2]), myPort);
                } else {
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, strReceived, myPort);
                }
            } else if (req_type.equals(Status_Query_Found)) {
                localcopy.put(split[2], split[3]);
            } else if (req_type.equals(Status_Delete_All)) {
                globalcopy.clear();
                localcopy.clear();
                Log.d("PA3", "Delete all Local Copy = " + localcopy.toString());
                Log.d("PA3", "Delete all global Copy = " + globalcopy.toString());
            } else if(req_type.equals(Status_Delete_One)) {
                if(localcopy.containsKey(split[2])) {
                    localcopy.remove(split[2]);
                    Log.d("PA3", "Delete one Local Copy = " + localcopy.toString());
                } else if(split[1].equals(myPort)){
                    Log.d("PA3", "Delete one Deleted already" );
                } else {
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, strReceived, myPort);
                }
            }

            return;
        }
        protected void onProgressUpdate(String... strings) {
            if (myPort.equals("11108") && tmap.size() == 5 - Node_Count && Node_Join_Complete) {
                Node_Join_Complete = false;
//                Set<String> keys = tmap.keySet();
//                List<String> sortedList = new ArrayList<String>(keys);
//                Collections.sort(sortedList);
//                String s_list = TextUtils.join(", ", sortedList);
                Log.d("PA3", "Node_Join_Complete - \t\n");
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, Status_Node_Join_Complete + "-" + myPort, myPort);
            }
        }
    }

        private class ClientTask extends AsyncTask<String, Void, Void> {

            @Override
            protected Void doInBackground(String... msgs) {
                String port = msgs[1], server_port = null;
                String msgToSend = msgs[0];
                String req_type = msgToSend.split("-")[0];
                if (req_type.equals(Status_Node_Join_Request)) {
                    sendMessage("11108", msgToSend);
                } else if (req_type.equals(Status_Node_Join_Complete)) {
                    findPredAndSucc();
                } else if (req_type.equals(Status_Msg_Forward)) {
                    sendMessage(successor, msgToSend);
                } else if (req_type.equals(Status_Query_All)) {
                    fetchall();
                } else if (req_type.equals(Status_Query_One)) {
                    sendMessage(successor, msgToSend);
                } else if(req_type.equals(Status_Query_Found)) {
                    sendMessage(msgToSend.split("-")[1], msgToSend);
                } else if (req_type.equals(Status_Delete_All)) {
                    Deleteall(msgToSend);
                } else if (req_type.equals(Status_Delete_One)) {
                    sendMessage(successor, msgToSend);
                } else if (req_type.equals(Status_Node_Number)) {
                    Log.d("PA3", "Port list - " + port_list.toString());
                    for (int i= 0; i<port_list.size(); i++) {
                        if(!port_list.get(i).equals("11108")) {
                            sendMessage(port_list.get(i), msgToSend);
                        }
                    }
                    Node_Join_Complete = true;
                    Node_Join_Complete_2 = true;
//                    countDownLatch.countDown();
                    Log.d("PA3", "Node_Number_Complete - " + Node_Count + "\t\n");
                }
                return null;
            }

            private void findPredAndSucc() {
                Iterator iter = tmap.entrySet().iterator();
                String pred = tmap.lastEntry().getValue();
                if (iter.hasNext()) {
                    Map.Entry curr_iter = (Map.Entry) iter.next();
                    String curr = (String) curr_iter.getValue();
                    while (iter.hasNext()) {
                        Map.Entry next = (Map.Entry) iter.next();
                        sendMessage((String) curr_iter.getValue(), Status_Node_Join_Complete + "-" + (String) curr_iter.getValue() + "-" + pred + "-" + (String) next.getValue());
                        pred = curr;
                        curr = (String) next.getValue();
                        curr_iter = next;
                    }
                    sendMessage((String) curr_iter.getValue(), Status_Node_Join_Complete + "-" + (String) curr_iter.getValue() + "-" + pred + "-" + (String) tmap.firstEntry().getValue());
                }
            }
        }

        private void sendMessage(String port, String msg) {
            try {
                Log.d("PA3", "Sending message to server - " + port + " - " + msg);
                Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(port));
                OutputStream os = socket.getOutputStream();
                PrintWriter out = new PrintWriter(os, true);
                out.println(msg);
                out.flush();
                BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                while(!socket.isClosed()) {
                    if (br.readLine().equals("Received")) {
//                        Log.d(TAG, "Received ACk from server");
                        socket.close();
                    } else {
                        Log.e(TAG, "Innder loop 2");
                    }

                }

                socket.close();

            } catch (NullPointerException e) {
                Log.e("tested", "ClientTask Null pointer send msg Exception");
                if(msg.split("-")[0].equals(Status_Node_Number)) {
                    Node_Count ++;
                }
            } catch (UnknownHostException e) {
                Log.e(TAG, "ClientTask UnknownHostException");
            } catch (IOException e) {
                Log.e("tested", "send message Io Exception ");
            }
        }

        @Override
        public int delete(Uri uri, String selection, String[] selectionArgs) {
            // TODO Auto-generated method stub
            if((predecessor == null && successor == null) ) {
                if(selection.contains("@") || selection.contains("*") ) {
                    localcopy.clear();
                } else {
                    localcopy.remove(selection);
                }
            } else if(selection.contains("@")) {
                localcopy.clear();
            } else if(selection.contains("*")) {
                AsyncTask task = new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, Status_Delete_All + "-" + myPort, myPort);
                while (task.getStatus() !=  AsyncTask.Status.FINISHED) {

                }
                localcopy.clear();
                globalcopy.clear();
//                Log.d("PA3", "Global Copy = " + globalcopy.toString());
            }  else {
                if(localcopy.containsKey(selection)) {
                    localcopy.remove(selection);
                } else {
                    AsyncTask task = new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, Status_Delete_One + "-" + myPort + "-" + selection, myPort);
                }
            }
            Log.d("PA3", "Req Local Copy = " + localcopy.toString());
            Log.d("PA3", "Req Global Copy = " + globalcopy.toString());
            return 0;
        }

        @Override
        public String getType(Uri uri) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public Uri insert(Uri uri, ContentValues values) {
            // TODO Auto-generated method stub
            try {
                String filename = genHash((String) values.get(KEY_FIELD));
                String fileContents = (String) values.get(VALUE_FIELD);
                Log.d("PA3", "Reached Insert - " + filename + " - " + fileContents);
                String f_name = (String) values.get(KEY_FIELD);
                if(predecessor == null && successor == null) {
                    localcopy.put(f_name, fileContents);
                } else if ((filename.compareTo(Hash_myport) <= 0 && filename.compareTo(Hash_predessor) > 0) || (Hash_predessor.compareTo(Hash_myport) >= 0 && (filename.compareTo(Hash_predessor) > 0 || filename.compareTo(Hash_myport) < 0))){
                    FileOutputStream outputStream;
//                    Log.d("PA3", "Reached Insert check");
                    try {
                        Context ctx = getContext();
                        assert ctx != null;
                        Log.d("PA3", "Value inserted - " + f_name + " " + fileContents);
                        localcopy.put(f_name, fileContents);
//                        SimpleDhtActivity.tv.append(filename + " " + fileContents + "\t\n");
                        outputStream = ctx.openFileOutput(f_name, MODE_PRIVATE);
                        outputStream.write(fileContents.getBytes());
                        outputStream.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
//                    Log.d("PA3", "Reached fwd check");
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, Status_Msg_Forward + "-" + myPort + "-" + values.get(KEY_FIELD) + "-" + values.get(VALUE_FIELD), myPort);
                }
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
            return uri;
        }



        public void fetchall() {
            for (int i = 0; i < ports.length; i++) {
                if(!ports[i].equals(myPort)) {
                    try {
                        Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                Integer.parseInt(ports[i]));
                        OutputStream os = socket.getOutputStream();
                        PrintWriter out = new PrintWriter(os, true);
                        out.println(Status_Query_All + "-" + myPort);
                        out.flush();
                        ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                        HashMap<String, String> obj = null;
                        while (!socket.isClosed()) {
                            obj = (HashMap<String, String>) in.readObject();
                            Log.d("tested", "innerloop");
                            if(obj != null) {
                                globalcopy.putAll(obj);
//                                Log.d("PA3", "Global Loop = " + globalcopy.toString());
                                socket.close();
                            }
                        }
                        socket.close();
                    } catch (UnknownHostException e) {
                        Log.e(TAG, "ClientTask UnknownHostException");
                    } catch (IOException e) {
                        Log.e("tested", "send message Io Exception - ");
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

    public void Deleteall(String msg) {
        for (int i = 0; i < ports.length; i++) {
            if(!ports[i].equals(myPort)) {
                sendMessage(ports[i], msg);
            }
        }
    }

        private MatrixCursor addToCursor(HashMap<String, String> copy) {
            MatrixCursor cursor = new MatrixCursor(new String[] {KEY_FIELD, VALUE_FIELD});
            Iterator iter = copy.entrySet().iterator();
            while(iter.hasNext()) {
                Map.Entry m = (Map.Entry)iter.next();
                cursor.addRow(new Object[] {m.getKey(), m.getValue()});
            }
            return cursor;
        }
        @Override
        public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
                            String sortOrder) {
            // TODO Auto-generated method stub
            Log.d("PA3", "Query - " + selection);
            MatrixCursor cursor = new MatrixCursor(new String[] {KEY_FIELD, VALUE_FIELD});
            if((predecessor == null && successor == null) ) {
                if(selection.contains("@") || selection.contains("*") ) {
                    cursor = addToCursor(localcopy);
                } else {
                    cursor.addRow(new Object[] {selection, localcopy.get(selection)});
                }
            } else if(selection.contains("@")) {
                cursor = addToCursor(localcopy);
//                Log.d("PA3", "Local Copy = " + localcopy.toString());
            } else if(selection.contains("*")) {
                AsyncTask task = new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, Status_Query_All + "-" + myPort, myPort);
                while (task.getStatus() !=  AsyncTask.Status.FINISHED) {

                }
                cursor = addToCursor(globalcopy);
//                Log.d("PA3", "Global Copy = " + globalcopy.toString());
            }  else {
                if(localcopy.containsKey(selection)) {
                    cursor.addRow(new Object[] {selection, localcopy.get(selection)});
                } else {
                    AsyncTask task = new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, Status_Query_One + "-" + myPort + "-" + selection, myPort);
                    while(!localcopy.containsKey(selection)) {
//                        Log.d("PA3", "Task loop");
                    }
                    if(localcopy.containsKey(selection)) {
//                        Log.d("PA3", "Retrieved Key - " + selection);
                        cursor.addRow(new Object[] {selection, localcopy.get(selection)});
                    }
                }

            }

//            Log.v("query", selection);
            return cursor;
        }

        @Override
        public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
            // TODO Auto-generated method stub
            return 0;
        }

        private String genHash(String input) throws NoSuchAlgorithmException {
            MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
            byte[] sha1Hash = sha1.digest(input.getBytes());
            Formatter formatter = new Formatter();
            for (byte b : sha1Hash) {
                formatter.format("%02x", b);
            }
            return formatter.toString();
        }

    @Override
    public boolean onCreate() {
        // TODO Auto-generated method stub
        mUri = buildUri("content", "edu.buffalo.cse.cse486586.groupmessenger2.provider");
        TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        myPort = String.valueOf((Integer.parseInt(portStr) * 2));
        try {
            Hash_myport = genHash(mapping.get(myPort));
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
        } catch (IOException e) {
            Log.e(TAG, "Can't create a ServerSocket");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        if (!myPort.equals("11108")) {
            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, Status_Node_Join_Request + "-" + myPort, myPort);
        } else {
            try {
                tmap.put(genHash("5554"), "11108");
                Thread.sleep(9000);
                Log.d("PA3", "Timeout Oncreate " + String.valueOf(tmap.size()));
                AsyncTask task = new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, Status_Node_Number + "-" + myPort, myPort);
                while (task.getStatus() == AsyncTask.Status.FINISHED) {

                }
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        return true;
    }

    }
